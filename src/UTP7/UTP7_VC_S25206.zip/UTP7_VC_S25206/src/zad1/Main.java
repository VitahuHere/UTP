/**
 *
 *  @author Vu Cong Minh S25206
 *
 */

package zad1;


public class Main {

  public static void main(String[] args) {
  }
}

/**
 *
 *  @author Vu Cong Minh S25206
 *
 */

package zad2;


public class Purchase {
}  

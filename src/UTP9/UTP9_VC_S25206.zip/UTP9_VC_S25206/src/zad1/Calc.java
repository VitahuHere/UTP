/**
 *
 *  @author Vu Cong Minh S25206
 *
 */

package zad1;


public class Calc {
}  
